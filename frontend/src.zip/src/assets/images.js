export  const images={
    user:require('./images/user.jpg')
}