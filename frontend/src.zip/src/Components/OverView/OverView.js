import React from 'react'
import { Nav } from '../Common/Nav'

export default function OverView() {
  return (
    <div>
      <Nav />
      <div class="content-wrapper">

        <section class="content-header">
          <h1> OverView</h1>
        </section>


        <section class="container-fluid content">
        </section>
      </div>

    </div>
  )
}
