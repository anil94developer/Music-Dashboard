# Music-Dashboard
Music dashboard



sudo ssh root@195.35.23.219
Dashboard@123!

<!-- old data remove  -->
rm -rf backend backend.zip

sudo scp backend.zip root@195.35.23.219:/var/www
unzip backend.zip -d backend
 
 